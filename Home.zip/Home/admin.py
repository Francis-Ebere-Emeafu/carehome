from django.contrib import admin
from Home.models import Farmer,Buyer


admin.site.register(Farmer)
admin.site.register(Buyer)
